import pandas as pd
import numpy as np

# Configurar semilla para consistencia de datos
np.random.seed(42)

# 1. Crear tabla de Ciclistas
ciclistas = {
    'cedula': [413200914, 213200920, 413200919, 113200919, 513200919,713200919, 1145209759,815235128,3214654789,852487451,413200989, 313200920, 713200919, 113200919, 673200919,213200919, 4145109759,36845217,7214654789,652458745],
    'nombre': ['Carlos Mendoza', 'Ana Silva', 'Luis Pérez', 'Sofía Gómez', 'Diego Torres', 'Jose Mora','Juan Roman', 'María Torres', 'Sofia Jara','Allan Herrera','Sebastian Marin','Gerardo Barrantes','Pedro Mora','Martin Lopez', 'William Mora','Andrey Campos','Francisco Cerdas', 'Ana María Pérez', 'Jazmin Castro','Jose Carlos Alvarado'],
    'provincia': ['Heredia', 'Alajuela', 'San José', 'Heredia', 'Alajueva', 'Puntarenas', 'Limon', 'Alajuela','Heredia','San José','Heredia', 'Alajuela', 'San José', 'Heredia', 'Alajueva', 'Puntarenas', 'Limon', 'Alajuela','Heredia','San José'],
}
df_ciclista = pd.DataFrame(ciclistas)



df_ciclista.to_csv('ciclista.csv', index=False)

# 2. Crear tabla de Rutas
rutas = {
    'id_ruta': [201, 202, 203, 204, 205],
    'nombre_ruta': ['Vuelta al Valle', 'Subida al Poas', 'Circuito Belen', 'Ruta de los Volcanes', 'Los Arrepentidos'],
    'distancia_km': [45.2, 12.8, 60.0, 85.5, 30.4],
    'desnivel_positivo_m': [350, 980, 120, 1650, 420],
    'tipo_terreno': ['Asfalto', 'Montaña', 'Asfalto', 'Mixto', 'Montaña']
}
df_ruta = pd.DataFrame(rutas)
df_ruta.to_csv('ruta.csv', index=False)

# 3. Crear tabla de Actividades (Historial)
n_actividades = 250
id_ciclistas_rep = np.random.choice(df_ciclista['cedula'], n_actividades)
id_rutas_rep = np.random.choice(df_ruta['id_ruta'], n_actividades)
fechas = pd.date_range(start='2026-01-01', periods=n_actividades, freq='D').strftime('%Y-%m-%d').tolist()

actividades = {
    'id_actividad': [300 + i for i in range(n_actividades)],
    'id_ciclista': id_ciclistas_rep,
    'id_ruta': id_rutas_rep,
    'fecha': fechas,
    'tiempo_minutos': [],
    'frecuencia_cardiaca_media': np.random.randint(130, 165, n_actividades)
}

# Simular tiempos basados de manera lógica en la distancia y dificultad
for i in range(n_actividades):
    ruta_id = id_rutas_rep[i]
    distancia = df_ruta[df_ruta['id_ruta'] == ruta_id]['distancia_km'].values[0]
    desnivel = df_ruta[df_ruta['id_ruta'] == ruta_id]['desnivel_positivo_m'].values[0]
    
    # Velocidad promedio más baja si la ruta tiene mucho desnivel
    vel_promedio = np.random.uniform(22, 30) if desnivel < 500 else np.random.uniform(12, 18)
    tiempo = round((distancia / vel_promedio) * 60, 1)
    actividades['tiempo_minutos'].append(tiempo)

df_actividad = pd.DataFrame(actividades)
df_actividad.to_csv('actividad.csv', index=False)

print("¡Archivos generados con éxito: ciclista.csv, ruta.csv y actividad.csv!")