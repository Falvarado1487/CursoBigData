import sys
from pyspark.sql import SparkSession

def main():
    spark = SparkSession.builder \
        .appName("Tarea1") \
        .master("local[*]") \
        .getOrCreate()
    spark.stop()
    if __name__ == "__main__":
       main()