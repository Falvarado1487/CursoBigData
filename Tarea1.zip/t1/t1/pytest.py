import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from funciones import load_DataFrame
from tests import calculate_total_kilometers_Por_Ciclista_dia,calculate_total_kilometers_Por_Ciclista,BusquedaNombrePersona,calculate_total_kilometers_Por_Persona_Provincia,calculate_total_kilometers_Por_Provincia

def pytest():
   spark = SparkSession.builder \
        .appName("pytest") \
        .master("local[*]") \
        .getOrCreate()

   datos = load_DataFrame()
   df1=calculate_total_kilometers_Por_Persona_Provincia(datos)
   df2=calculate_total_kilometers_Por_Ciclista(datos)
   df3=BusquedaNombrePersona("Freddy Alvarado",datos)
   df4=BusquedaNombrePersona("William Mora",datos)
   
   print("\n" + "="*40)
   print("   TITULO: Total kilometers Por Persona Provincia")
   print("="*40)
   df1.show(5)
 
   print("\n" + "="*40)
   print("   TITULO: Total kilometers Por Persona")
   print("="*40)
   df2.show(5)
   
   print("\n" + "="*40)
   print("   TITULO: Busqueda de una persona en especifico (NO EXISTE PERSONA)")
   print("="*40)
   if df3.isEmpty():
    print("El DataFrame está vacío") 
   else:
    df3.show(3)

   print("\n" + "="*40)
   print("   TITULO: Busqueda de una persona en especifico (SI EXISTE PERSONA)")
   print("="*40)
   if df4.isEmpty():
    print("El DataFrame está vacío") 
   else:
    df4.show(5)
 

   spark.stop()

if __name__ == "__main__":
       pytest()
