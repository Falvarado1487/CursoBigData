import findspark
from pyspark.sql import DataFrame
from pyspark.sql.functions import col
findspark.init()
from pyspark.sql import SparkSession 
from pyspark.sql import functions as F

spark = SparkSession.builder.appName('Tarea1').getOrCreate()

pathCiclistas ='data/ciclista.csv'
pathRutas='data/ruta.csv'
pathActividad='data/actividad.csv'

def load_Ciclistas(spark: SparkSession,file_path: str) -> DataFrame:
 dfCiclistas = spark.read.csv(file_path, inferSchema=True, header=True)
 return dfCiclistas 

def load_rutas(spark: SparkSession,file_path: str) -> DataFrame:
 dfRutas = spark.read.csv(file_path, inferSchema=True, header=True)
 return dfRutas 

def load_Actividad(spark: SparkSession,file_path: str)  -> DataFrame:
 dfActividad = spark.read.csv(file_path, inferSchema=True, header=True)
 return dfActividad 

def calculate_Pormedio_total_kilometers_Persona_dia(dfDatos: DataFrame) -> DataFrame:
   group_cols = ['cedula','nombre']
   dffinal=dfDatos.groupBy(group_cols).agg(F.round(F.avg("distancia_km"),2).alias("total_Promedio_km")).orderBy(F.desc("total_Promedio_km")) 
   return dffinal

def calculate_total_kilometers_Por_Persona(dfDatos: DataFrame) -> DataFrame:
   group_cols = ['cedula','nombre']
   dfFinal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km")).orderBy(F.desc("total_km"))
   return dfFinal
def calculate_kilometers_Por_Persona_Provincia(dfDatos: DataFrame) -> DataFrame:
   dfDatos=dfDatos.withColumn("dia_nombre", F.date_format("fecha", "EEEE"))
   group_cols = ['provincia','cedula','nombre']
   definal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km")).orderBy(F.desc("total_km"))
   return definal

def load_DataFrame() -> DataFrame:
   dfCiclistas = load_Ciclistas(spark,pathCiclistas)
   dfRutas = load_rutas(spark,pathRutas)
   dfActividad = load_Actividad(spark,pathActividad)
   dfCiclistaActividad=dfCiclistas.join(dfActividad, dfCiclistas.cedula == dfActividad.id_ciclista, "inner").select(dfCiclistas.cedula,dfCiclistas.nombre,     dfCiclistas.provincia, dfActividad.id_ruta, dfActividad.tiempo_minutos,dfActividad.fecha)
   dfCiclistaActividadRuta=dfCiclistaActividad.join(dfRutas, dfCiclistaActividad.id_ruta == dfRutas.id_ruta, "inner").select(dfCiclistaActividad.cedula,dfCiclistaActividad.nombre, dfCiclistas.provincia, dfCiclistaActividad.id_ruta, dfRutas.nombre_ruta, dfRutas.distancia_km ,dfActividad.tiempo_minutos,dfActividad.fecha)  
   return dfCiclistaActividadRuta    