import findspark
from pyspark.sql import DataFrame
from pyspark.sql.functions import col
findspark.init()
from pyspark.sql import SparkSession 
from pyspark.sql import functions as F

spark = SparkSession.builder.appName('Tarea1').getOrCreate()

def calculate_total_kilometers_Por_Provincia(dfDatos: DataFrame) -> DataFrame:
   group_cols = ['provincia']
   dfDatos=dfDatos.select("provincia","distancia_km")
   dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km_Provincia")).orderBy(F.desc("total_km_Provincia"))
   return dfDatos
  
def calculate_total_kilometers_Por_dia(dfDatos: DataFrame) -> DataFrame:
   dfDatos=dfDatos.withColumn("dia_nombre", F.date_format("fecha", "EEEE"))
   group_cols = ['dia_nombre']
   dfDatos=dfDatos.select("dia_nombre","distancia_km")
   dfFinal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km_fecha")).orderBy(F.desc("total_km_dia"))
   return dfFinal

def calculate_total_kilometers_Por_Persona_Provincia(dfDatos: DataFrame) -> DataFrame:
   group_cols = ['provincia','cedula','nombre']
   dfDatos=dfDatos.select("cedula", "nombre", "provincia","distancia_km")
   dfFinal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km")).orderBy(F.desc("total_km"))
   return dfFinal

def calculate_total_kilometers_Por_Ciclista_dia(dfDatos: DataFrame) -> DataFrame:
   dfDatos=dfDatos.withColumn("dia_nombre", F.date_format("fecha", "EEEE"))
   group_cols = ['dia_nombre','cedula','nombre']
   dfFinal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km_dia")).orderBy(F.desc("total_km_dia"))
   return dfFinal 

def calculate_total_kilometers_Por_Ciclista(dfDatos: DataFrame) -> DataFrame:
   group_cols = ['cedula','nombre']
   dfFinal=dfDatos.groupBy(group_cols).agg(F.round(F.sum("distancia_km"),2).alias("total_km")).orderBy(F.desc("total_km")) 
   return dfFinal

def BusquedaNombrePersona(nombre: str, dfDatos: DataFrame )-> DataFrame:
    df_resultado = dfDatos.filter(F.col("nombre").contains(nombre))
    return df_resultado
   
   