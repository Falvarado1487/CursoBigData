import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from funciones import load_DataFrame,calculate_Pormedio_total_kilometers_Persona_dia,calculate_kilometers_Por_Persona_Provincia

def main():
   spark = SparkSession.builder \
        .appName("Tarea1") \
        .master("local[*]") \
        .getOrCreate()

   def top_ciclistas():
     datos = load_DataFrame()
     promedio_kilometros_Persona_dia=calculate_Pormedio_total_kilometers_Persona_dia(datos)
     suma_kilometros_Persona=calculate_kilometers_Por_Persona_Provincia(datos)
     data=suma_kilometros_Persona.join(promedio_kilometros_Persona_dia, suma_kilometros_Persona.cedula==promedio_kilometros_Persona_dia.cedula, 'inner').select(suma_kilometros_Persona.cedula,suma_kilometros_Persona.nombre,suma_kilometros_Persona.provincia,suma_kilometros_Persona.total_km,promedio_kilometros_Persona_dia.total_Promedio_km)
     return data
   
   resultado=top_ciclistas()
   resultado=resultado.distinct()
   resultado.orderBy(F.col("total_km").desc(), F.col("total_Promedio_km").desc()).show(5)
   

   spark.stop()

if __name__ == "__main__":
       main()
